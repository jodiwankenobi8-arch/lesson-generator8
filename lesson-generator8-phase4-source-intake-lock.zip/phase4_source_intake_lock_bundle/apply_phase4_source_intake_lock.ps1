$ErrorActionPreference = "Stop"

function Write-Utf8NoBom {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Content
    )
    $encoding = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $encoding)
}

function Replace-OrThrow {
    param(
        [Parameter(Mandatory = $true)][string]$Text,
        [Parameter(Mandatory = $true)][string]$OldValue,
        [Parameter(Mandatory = $true)][string]$NewValue,
        [Parameter(Mandatory = $true)][string]$Label
    )

    if (-not $Text.Contains($OldValue)) {
        throw "Expected block not found for: $Label"
    }

    return $Text.Replace($OldValue, $NewValue)
}

function RegexReplace-OrThrow {
    param(
        [Parameter(Mandatory = $true)][string]$Text,
        [Parameter(Mandatory = $true)][string]$Pattern,
        [Parameter(Mandatory = $true)][string]$Replacement,
        [Parameter(Mandatory = $true)][string]$Label
    )

    $updated = [System.Text.RegularExpressions.Regex]::Replace(
        $Text,
        $Pattern,
        $Replacement,
        [System.Text.RegularExpressions.RegexOptions]::Singleline
    )

    if ($updated -eq $Text) {
        throw "Expected regex block not found for: $Label"
    }

    return $updated
}

$repoRoot = (Get-Location).Path

$matrixPath = Join-Path $repoRoot "docs/project-notes/SUPPORTED_SOURCE_MATRIX_CURRENT.md"
$materialsPath = Join-Path $repoRoot "src/pages/MaterialsPage.tsx"
$inputsPath = Join-Path $repoRoot "src/pages/InputsPage.tsx"
$storeTestPath = Join-Path $repoRoot "src/state/useLessonStore.test.ts"
$startHerePath = Join-Path $repoRoot "START_HERE_CURRENT_TRUTH.md"
$projectStatePath = Join-Path $repoRoot "PROJECT_CURRENT_STATE.md"

foreach ($path in @($matrixPath, $materialsPath, $inputsPath, $storeTestPath, $startHerePath, $projectStatePath)) {
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Missing required file: $path"
    }
}

$matrixContent = @'
# Supported source matrix — current live contract

Status:
- current intake is upload based through the Materials page
- current uploaded source formats include text/docs and image uploads
- broader intake expansion is not locked yet
- do not imply web links / URLs or pasted text as separate first-class Materials-page lanes until that UI work is explicitly landed
- do not imply screenshots / photos are equal to clean parser-first text sources; image uploads currently depend on bounded OCR recovery and may still be caution-scored or blocked

## Current supported source intake

Entry point:
- Materials page upload flow

Supported file types:
- `.txt`
- `.pdf`
- `.docx`
- `.pptx`
- `.html`
- `.htm`
- `.png`
- `.jpg`
- `.jpeg`
- `.webp`

Lane roles:
- curriculum = content authority
- exemplar = presentation / structure authority

Trust rule:
- generation depends on usable materials, not merely ready materials
- parser-first document extraction remains the primary path for `.txt`, `.pdf`, `.docx`, `.pptx`, `.html`, and `.htm`
- screenshots / photos are supported as uploaded image sources through bounded OCR recovery
- image uploads stay visible for the teacher, but they should not steer lesson generation until OCR recovers readable text strongly enough to be usable
- OCR exists only as a bounded recovery path inside the current extraction flow

## Not yet first-class

These should be treated as future-expansion ideas, not current product promises:
- web links / URLs as a Materials-page source lane
- pasted text as a separate Materials-page lane
- audio / video sources
- multi-provider OCR orchestration
- AI-first intake interpretation

## Teacher-facing wording guardrails

- say `upload-based intake` rather than implying broad multi-source intake
- say `screenshots / photos are supported through bounded OCR` rather than implying guaranteed grounding quality
- keep curriculum and exemplar authority roles explicit
- keep `usable materials` language explicit whenever generation gating is described

## Finish recommendation

Before broader intake is expanded, keep the product contract explicit:
- upload-based intake is the current truth
- image uploads are supported, but only through bounded OCR recovery and trust scoring
- broader source expansion should land only with an explicit source matrix, trust behavior, and validation plan
'@
Write-Utf8NoBom -Path $matrixPath -Content $matrixContent

$materials = Get-Content -LiteralPath $materialsPath -Raw -Encoding UTF8

$materials = Replace-OrThrow `
    -Text $materials `
    -OldValue '          Current intake is upload based. Supported source formats: .txt, .pdf, .docx, .pptx, .html, and .htm. Add sources here, then generate only from usable curriculum and exemplar sources.' `
    -NewValue '          Current intake is upload based. Supported source formats: .txt, .pdf, .docx, .pptx, .html, .htm, .png, .jpg, .jpeg, and .webp. Screenshots and photos use bounded OCR recovery and still must become usable before they can ground lesson generation.' `
    -Label "Materials intro copy"

$materials = Replace-OrThrow `
    -Text $materials `
    -OldValue 'accept=".txt,.pdf,.docx,.pptx,.html,.htm"' `
    -NewValue 'accept=".txt,.pdf,.docx,.pptx,.html,.htm,.png,.jpg,.jpeg,.webp"' `
    -Label "Materials accept attr 1"

$materials = Replace-OrThrow `
    -Text $materials `
    -OldValue 'accept=".txt,.pdf,.docx,.pptx,.html,.htm"' `
    -NewValue 'accept=".txt,.pdf,.docx,.pptx,.html,.htm,.png,.jpg,.jpeg,.webp"' `
    -Label "Materials accept attr 2"

$materials = RegexReplace-OrThrow `
    -Text $materials `
    -Pattern 'const id = addMaterial\(role, file\.name\)\s+try \{\s+const fileBuffer = await file\.arrayBuffer\(\)\s+const fileContent = shouldCapturePlainText\(file\.name\) \? await file\.text\(\) : null\s+setMaterialSource\(id, \{\s+fileBuffer,\s+fileContent,\s+\}\)' `
    -Replacement @'
const sourceKind = inferSourceKindFromFile(file)
      const sourceLabel = buildSourceLabel(sourceKind)
      const sourceMimeType = file.type?.trim() ? file.type : null
      const id = addMaterial(role, file.name, {
        sourceKind,
        sourceLabel,
        sourceMimeType,
      })

      try {
        const fileBuffer = await file.arrayBuffer()
        const fileContent = shouldCapturePlainText(file.name) ? await file.text() : null

        setMaterialSource(id, {
          fileBuffer,
          fileContent,
          sourceKind,
          sourceLabel,
          sourceMimeType,
        })
'@ `
    -Label "Materials source provenance block"

$materials = Replace-OrThrow `
    -Text $materials `
    -OldValue @'
function shouldCapturePlainText(fileName: string): boolean {
  const normalized = fileName.toLowerCase()
  return normalized.endsWith(".txt") || normalized.endsWith(".html") || normalized.endsWith(".htm")
}
'@ `
    -NewValue @'
function inferSourceKindFromFile(file: File): MaterialSourceKind {
  const mimeType = file.type.toLowerCase().trim()
  const normalizedName = file.name.toLowerCase().trim()

  if (
    mimeType.startsWith("image/") ||
    normalizedName.endsWith(".png") ||
    normalizedName.endsWith(".jpg") ||
    normalizedName.endsWith(".jpeg") ||
    normalizedName.endsWith(".webp")
  ) {
    return "image_upload"
  }

  return "file_upload"
}

function buildSourceLabel(sourceKind: MaterialSourceKind): string {
  return sourceKind === "image_upload" ? "Screenshot or photo" : "Uploaded file"
}

function shouldCapturePlainText(fileName: string): boolean {
  const normalized = fileName.toLowerCase()
  return normalized.endsWith(".txt") || normalized.endsWith(".html") || normalized.endsWith(".htm")
}
'@ `
    -Label "Materials helper functions"

Write-Utf8NoBom -Path $materialsPath -Content $materials

$inputs = Get-Content -LiteralPath $inputsPath -Raw -Encoding UTF8

$inputs = Replace-OrThrow `
    -Text $inputs `
    -OldValue @'
        <div style={{ marginTop: "var(--space-lg)" }}>
          <div style={noticeStyle}>
            Results can generate once the truly required lesson information is in
            place: grade, subject, and skill / focus. Standard(s), topic / text /
            unit, duration, and extra notes stay optional on this page.
          </div>
        </div>
'@ `
    -NewValue @'
        <div style={{ marginTop: "var(--space-lg)" }}>
          <div style={noticeStyle}>
            Results can generate once the truly required lesson information is in
            place: grade, subject, and skill / focus. Standard(s), topic / text /
            unit, duration, and extra notes stay optional on this page.
          </div>
        </div>

        <div style={{ marginTop: "var(--space-sm)" }}>
          <div style={noticeStyle}>
            Materials intake is currently upload based. Supported source formats on the next page are .txt, .pdf, .docx, .pptx, .html, .htm, .png, .jpg, .jpeg, and .webp. Screenshots and photos use bounded OCR recovery and still must become usable before they can ground generation.
          </div>
        </div>
'@ `
    -Label "Inputs source-intake notice"

Write-Utf8NoBom -Path $inputsPath -Content $inputs

$storeTest = Get-Content -LiteralPath $storeTestPath -Raw -Encoding UTF8

$anchorTest = @'
  it("processMaterial preserves pasted-text source provenance for non-file intake", async () => {
    const store = useLessonStore.getState()
    const materialId = store.addMaterial("curriculum", "Copied curriculum excerpt", {
      sourceKind: "pasted_text",
      sourceLabel: "Pasted text",
      sourceMimeType: "text/plain",
    })

    store.setMaterialSource(materialId, {
      fileBuffer: null,
      fileContent: [
        "RF.1.3",
        "Objective: Blend and read short a CVC words.",
        "Teacher says: Tap the sounds and read the word.",
      ].join("\n"),
      sourceKind: "pasted_text",
      sourceLabel: "Pasted text",
      sourceMimeType: "text/plain",
    })

    await useLessonStore.getState().processMaterial(materialId)

    const material = useLessonStore
      .getState()
      .materials.find((item) => item.id === materialId)

    expect(material).toBeTruthy()
    expect(material!.status).toBe("ready")
    expect(material!.sourceKind).toBe("pasted_text")
    expect(material!.sourceLabel).toBe("Pasted text")
    expect(material!.sourceMimeType).toBe("text/plain")
    expect(material!.analysis?.extractionMetadata?.provenance).toEqual({
      sourceKind: "pasted_text",
      sourceLabel: "Pasted text",
      originalType: "txt",
    })
  })
'@

$newImageTest = @'

  it("processMaterial preserves image-upload source provenance for screenshot/photo intake", async () => {
    const store = useLessonStore.getState()
    const materialId = store.addMaterial("exemplar", "screenshot-guide.png", {
      sourceKind: "image_upload",
      sourceLabel: "Screenshot or photo",
      sourceMimeType: "image/png",
    })

    store.setMaterialSource(materialId, {
      fileBuffer: new TextEncoder().encode("fake-image").buffer,
      fileContent: null,
      sourceKind: "image_upload",
      sourceLabel: "Screenshot or photo",
      sourceMimeType: "image/png",
    })

    await useLessonStore.getState().processMaterial(materialId)

    const material = useLessonStore
      .getState()
      .materials.find((item) => item.id === materialId)

    expect(material).toBeTruthy()
    expect(material!.status).toBe("ready")
    expect(material!.sourceKind).toBe("image_upload")
    expect(material!.sourceLabel).toBe("Screenshot or photo")
    expect(material!.sourceMimeType).toBe("image/png")
    expect(material!.analysis?.extractionMetadata?.method).toBe("ocr")
    expect(material!.analysis?.extractionMetadata?.provenance).toEqual({
      sourceKind: "image_upload",
      sourceLabel: "Screenshot or photo",
      originalType: "image",
    })
  })
'@

$storeTest = Replace-OrThrow `
    -Text $storeTest `
    -OldValue $anchorTest `
    -NewValue ($anchorTest + $newImageTest) `
    -Label "Store provenance image test"

Write-Utf8NoBom -Path $storeTestPath -Content $storeTest

$startHere = Get-Content -LiteralPath $startHerePath -Raw -Encoding UTF8
$startHere = Replace-OrThrow `
    -Text $startHere `
    -OldValue '- Current milestone: orchard/artifact finish pass is landed locally; export truth remains locked; manual/browser validation is still pending' `
    -NewValue '- Current milestone: orchard/artifact finish pass is landed locally; broader source-intake matrix lock is now also landed; export truth remains locked' `
    -Label "START_HERE current milestone"

$startHere = Replace-OrThrow `
    -Text $startHere `
    -OldValue '- Current active seam: doc/commit closeout for the orchard finish pass, then broader source-intake matrix' `
    -NewValue '- Current active seam: deliberate OCR expansion after the source-intake matrix lock' `
    -Label "START_HERE current active seam"

$startHere = Replace-OrThrow `
    -Text $startHere `
    -OldValue '- supported source matrix is documented in `docs/project-notes/SUPPORTED_SOURCE_MATRIX_CURRENT.md`' `
    -NewValue @'
- supported source matrix is documented in `docs/project-notes/SUPPORTED_SOURCE_MATRIX_CURRENT.md`
- broader source-intake matrix lock is now aligned across docs, UI, store provenance, and tests
- current upload-based source formats now explicitly include `.png`, `.jpg`, `.jpeg`, and `.webp`
- Materials now records uploaded-file vs screenshot/photo provenance explicitly for the live extraction pipeline
'@ `
    -Label "START_HERE landed source-intake bullets"

$startHere = Replace-OrThrow `
    -Text $startHere `
    -OldValue '- broader intake/OCR expansion is still not part of the just-finished orchard pass' `
    -NewValue @'
- broader source-intake matrix lock is now explicit across docs, UI, store provenance, and tests
- screenshots / photos are supported only through bounded OCR recovery and still must become usable before they can ground generation
- web links / URLs and pasted text are still not first-class Materials-page lanes
- deliberate OCR expansion is still the next seam after this matrix lock
'@ `
    -Label "START_HERE what is still true"

$startHere = Replace-OrThrow `
    -Text $startHere `
    -OldValue @'
## Best next move
- keep the current code/docs aligned by committing this orchard finish pass cleanly
- after that, move to the broader source-intake matrix
- then do deliberate OCR expansion
- keep bounded AI later, only if still wanted
'@ `
    -NewValue @'
## Best next move
- do deliberate OCR expansion next
- only then consider broader intake lanes such as web links / URLs or a pasted-text Materials-page entry
- keep bounded AI later, only if still wanted
- do not reopen export truth or orchard finish-pass work unless live proof shows drift
'@ `
    -Label "START_HERE best next move"

Write-Utf8NoBom -Path $startHerePath -Content $startHere

$projectState = Get-Content -LiteralPath $projectStatePath -Raw -Encoding UTF8
$projectState = Replace-OrThrow `
    -Text $projectState `
    -OldValue '- broader intake/OCR expansion is still not started' `
    -NewValue @'
- broader source-intake matrix lock is now landed across docs, UI, store provenance, and tests
- deliberate OCR expansion is still not started
- web links / URLs and pasted text are still not first-class Materials-page lanes
'@ `
    -Label "PROJECT_CURRENT_STATE not done yet"

$projectState = Replace-OrThrow `
    -Text $projectState `
    -OldValue '- the next seam after doc/commit closeout is still to be started' `
    -NewValue '- the next seam after the source-intake matrix lock is deliberate OCR expansion' `
    -Label "PROJECT_CURRENT_STATE next seam line"

$projectState = Replace-OrThrow `
    -Text $projectState `
    -OldValue '- supported source matrix is documented in `docs/project-notes/SUPPORTED_SOURCE_MATRIX_CURRENT.md`' `
    -NewValue @'
- supported source matrix is documented in `docs/project-notes/SUPPORTED_SOURCE_MATRIX_CURRENT.md`
- broader source-intake matrix lock is now aligned across docs, UI, store provenance, and tests
- current upload-based source formats now explicitly include `.png`, `.jpg`, `.jpeg`, and `.webp`
- Materials now records uploaded-file vs screenshot/photo provenance explicitly for the live extraction pipeline
'@ `
    -Label "PROJECT_CURRENT_STATE done bullets"

$projectState = Replace-OrThrow `
    -Text $projectState `
    -OldValue @'
## Top next steps
1. commit the orchard/artifact finish pass cleanly
2. start the broader source-intake matrix
3. do deliberate OCR expansion after that
4. keep bounded AI later, only if still wanted
'@ `
    -NewValue @'
## Top next steps
1. do deliberate OCR expansion
2. only then consider broader intake lanes such as web links / URLs or a pasted-text Materials-page entry
3. keep bounded AI later, only if still wanted
4. do not reopen export truth or orchard finish-pass work unless live proof shows drift
'@ `
    -Label "PROJECT_CURRENT_STATE top next steps"

Write-Utf8NoBom -Path $projectStatePath -Content $projectState

Write-Host ""
Write-Host "============================================================"
Write-Host "==============================SUMMARY========================"
Write-Host "Status: phase-4-source-intake-lock ready"
Write-Host "Updated: docs/project-notes/SUPPORTED_SOURCE_MATRIX_CURRENT.md"
Write-Host "Updated: src/pages/MaterialsPage.tsx"
Write-Host "Updated: src/pages/InputsPage.tsx"
Write-Host "Updated: src/state/useLessonStore.test.ts"
Write-Host "Updated: START_HERE_CURRENT_TRUTH.md"
Write-Host "Updated: PROJECT_CURRENT_STATE.md"
Write-Host "============================================================"
