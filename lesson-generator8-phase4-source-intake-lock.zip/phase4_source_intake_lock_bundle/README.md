# Phase 4 source-intake matrix lock

This bundle treats the current active seam as the broader source-intake matrix lock.

What it patches:
- docs/project-notes/SUPPORTED_SOURCE_MATRIX_CURRENT.md
- src/pages/MaterialsPage.tsx
- src/pages/InputsPage.tsx
- src/state/useLessonStore.test.ts
- START_HERE_CURRENT_TRUTH.md
- PROJECT_CURRENT_STATE.md

Goals:
- keep curriculum = content authority
- keep exemplar = presentation / structure authority
- keep generation gated on usable materials
- align docs/UI/store/tests with the live engine support already present for uploaded image sources
- do not overclaim links / URLs or pasted text as first-class Materials-page lanes
- do not broaden OCR beyond the current bounded recovery path

Apply from repo root:
- powershell -ExecutionPolicy Bypass -File .\apply_phase4_source_intake_lock.ps1

Recommended follow-up checks:
- npm run test -- src/state/useLessonStore.test.ts src/engine/extraction.test.ts
- npm run build
